const r="/assets/pdf.worker.min-yatZIOMy.mjs";export{r as default};
